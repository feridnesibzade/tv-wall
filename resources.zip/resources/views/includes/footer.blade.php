<footer>
    <div class="container">
        <div class="footer__inner">
            <p>MyWall © 2020-2024</p>
            <ul>
                <li><img src="/storage/img/footer (2).png" alt="" /></li>
                <li><img src="/storage/img/footer (1).png" alt="" /></li>
                <li><img src="/storage/img/footer (3).png" alt="" /></li>
            </ul>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="/assets/js/app.js"></script>
<script>
    Fancybox.bind("[data-fancybox]", {
        // Your custom options
    });
</script>
@stack('footer')
</body>

</html>
