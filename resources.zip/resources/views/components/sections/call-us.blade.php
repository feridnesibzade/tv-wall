<section style="margin-top: 10px; margin-bottom:10px;">
    <div class="responsive-phone" style="width: 100%; font-weight:250; text-align:center">
        <a href="tel:{{ trim($settings->phone) }}">
            <img src="/storage/img/phone.png" class="tel-icon" alt="">{{ $settings->phone }}
        </a>
    </div>
</section>
