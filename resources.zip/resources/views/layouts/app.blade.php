@include('includes.head')
@include('includes.header')

@yield('content')

@include('includes.footer')



    
        
        