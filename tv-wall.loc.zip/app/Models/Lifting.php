<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lifting extends Model
{
    public $fillable = ['title', 'price'];
}
