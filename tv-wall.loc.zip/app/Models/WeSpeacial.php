<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WeSpeacial extends Model
{
    public $fillable = ['title', 'description', 'detail'];
}
