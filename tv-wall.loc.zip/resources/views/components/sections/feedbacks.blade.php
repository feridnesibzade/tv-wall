<section class="feedback">
    <div class="swiper">
        <div class="swiper-wrapper">
            @foreach ($data['feedback'] as $feedback)
                <a href="{{ $feedback->author_url }}" target="_blank" class="swiper-slide">
                    <div class="feedback__item">
                        <div class="feedback__item__header">
                            <div>
                                <img src="{!! $feedback->profile_photo_url !!}" alt="" />
                                <div>
                                    <p>{{ ucfirst($feedback->author_name) }}</p>
                                    <span>{{ $feedback->relative_time_description }}</span>
                                </div>
                            </div>
                            {{-- <img src="/storage/{{ $feedback->logo }}" alt="" /> --}}
                        </div>
                        <div class="feedback___item__content">
                            {!! substr($feedback->text, 0, 350) . '...' !!}
                        </div>
                    </div>
                </a>
            @endforeach

        </div>
    </div>
    <img class="slider-prev" src="img/slider-prev.png" alt="" />
    <img class="slider-next" src="img/slider-next.png" alt="" />
</section>
@push('footer')
    <script></script>
@endpush
